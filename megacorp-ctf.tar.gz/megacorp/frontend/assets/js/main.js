function show(id) { document.getElementById(id).classList.remove('hidden'); }
function hide(id) { document.getElementById(id).classList.add('hidden'); }
function text(id, t) { document.getElementById(id).textContent = t; }

function showPage(name) {
  document.querySelectorAll('.page').forEach(p => { p.classList.remove('active'); p.style.display='none'; });
  const page = document.getElementById('page-' + name);
  page.style.display = 'flex';
  page.classList.add('active');
}

async function doLogin() {
  const username = document.getElementById('login-user').value;
  const password = document.getElementById('login-pass').value;
  hide('login-error'); hide('login-success');
  try {
    const res  = await fetch('/api/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username,password}) });
    const data = await res.json();
    if (data.success) {
      text('login-success', '✅ Connexion réussie !\n🚩 ' + data.flag);
      show('login-success');
      setTimeout(() => {
        document.getElementById('logged-user').textContent = data.user;
        document.getElementById('flag1').textContent = '🚩 ' + data.flag;
        showPage('dashboard');
      }, 1500);
    } else {
      text('login-error', '❌ ' + data.message); show('login-error');
    }
  } catch(e) { text('login-error','❌ Impossible de contacter le serveur.'); show('login-error'); }
}

async function doUpload() {
  const fileInput = document.getElementById('file-input');
  const file = fileInput.files[0];
  hide('upload-error'); hide('upload-success');
  if (!file) return;
  const formData = new FormData();
  formData.append('file', file);
  try {
    const res  = await fetch('/api/upload', { method:'POST', body:formData });
    const data = await res.json();
    if (data.success) {
      text('upload-success', `✅ ${data.message}\n📁 ${data.path}\n🚩 ${data.flag}`);
      show('upload-success');
      setTimeout(() => {
        document.getElementById('flag2').textContent = '🚩 ' + data.flag;
        document.getElementById('rce-file').value = file.name;
        showPage('rce');
      }, 2000);
    } else { text('upload-error','❌ '+data.message); show('upload-error'); }
  } catch(e) { text('upload-error','❌ Impossible de contacter le serveur.'); show('upload-error'); }
}

async function doRCE() {
  const file = document.getElementById('rce-file').value;
  hide('rce-error'); hide('rce-success');
  try {
    const res  = await fetch('/api/exec?file=' + encodeURIComponent(file));
    const data = await res.json();
    if (data.success) {
      text('rce-success', `✅ Exécution réussie !\n\n$ node /uploads/${file}\n${data.output}\n🚩 FLAG FINAL : ${data.flag}`);
      show('rce-success');
    } else { text('rce-error','❌ '+data.message); show('rce-error'); }
  } catch(e) { text('rce-error','❌ Impossible de contacter le serveur.'); show('rce-error'); }
}
