const express = require('express');
const mysql   = require('mysql2');
const cors    = require('cors');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { execSync } = require('child_process');

const app = express();
app.use(express.json());
app.use(cors());

// ── Connexion MariaDB ──────────────────────────────────────
const db = mysql.createConnection({
  host: 'db', port: 3306,
  user: 'root', password: 'rootpassword', database: 'ctf_db'
});
db.connect(err => {
  if (err) console.error('Erreur BDD:', err);
  else     console.log('[+] Connecté à MariaDB');
});

// ── Upload (aucune vérification = VULNÉRABLE) ──────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, '/app/uploads/'),
  filename:    (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage });

// ══════════════════════════════════════════════════════════
// ÉTAPE 1 — SQLi : Bypass de la page de login
// Payload : admin' OR '1'='1' --
// ══════════════════════════════════════════════════════════
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  // ⚠️ Concaténation directe = VULNÉRABLE intentionnellement
  const query = `SELECT * FROM employees WHERE username = '${username}' AND password = '${password}'`;
  console.log('[SQLi] Requête:', query);

  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ success: false, message: 'Erreur SQL: ' + err.message });
    if (results.length > 0) {
      db.query("SELECT flag FROM flags WHERE step='sqli'", (e, rows) => {
        const flag = rows && rows[0] ? rows[0].flag : 'FLAG{STEP1_SQLi_Auth_Bypass}';
        return res.json({ success: true, flag, user: results[0].username });
      });
    } else {
      return res.json({ success: false, message: 'Identifiants incorrects.' });
    }
  });
});

// ══════════════════════════════════════════════════════════
// ÉTAPE 2 — File Upload : Upload d'un fichier sans restriction
// Upload un .js malveillant → exécutable par le serveur
// ══════════════════════════════════════════════════════════
app.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'Aucun fichier.' });
  console.log('[Upload] Fichier reçu:', req.file.originalname);
  db.query("SELECT flag FROM flags WHERE step='upload'", (e, rows) => {
    const flag = rows && rows[0] ? rows[0].flag : 'FLAG{STEP2_FileUpload_Webshell}';
    return res.json({
      success: true,
      message: `Fichier "${req.file.originalname}" uploadé avec succès.`,
      path: `/uploads/${req.file.originalname}`,
      flag
    });
  });
});

// ══════════════════════════════════════════════════════════
// ÉTAPE 3 — RCE : Exécution d'un fichier .js uploadé
// Appelle /api/exec?file=shell.js
// ══════════════════════════════════════════════════════════
app.get('/exec', (req, res) => {
  const file = req.query.file;
  if (!file) return res.status(400).json({ success: false, message: 'Paramètre ?file= manquant.' });

  const filepath = path.join('/app/uploads', file);
  if (!fs.existsSync(filepath)) {
    return res.status(404).json({ success: false, message: `Fichier "${file}" introuvable dans /uploads/.` });
  }

  try {
    // ⚠️ Exécution directe du fichier uploadé = RCE intentionnelle
    const result = execSync(`node ${filepath}`, { timeout: 3000 }).toString();
    db.query("SELECT flag FROM flags WHERE step='rce'", (e, rows) => {
      const flag = rows && rows[0] ? rows[0].flag : 'FLAG{STEP3_RCE_MegaCorp_Pwned}';
      return res.json({ success: true, output: result, flag });
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erreur exécution: ' + err.message });
  }
});

app.listen(5000, () => console.log('[+] Backend MegaCorp démarré sur le port 5000'));
