
function show(id) { document.getElementById(id).classList.remove("hidden"); }
function hide(id) { document.getElementById(id).classList.add("hidden"); }
function setText(id, t) { document.getElementById(id).textContent = t; }

function showPage(name) {
  document.querySelectorAll(".page").forEach(p => {
    p.classList.remove("active");
    p.style.display = "none";
  });
  const page = document.getElementById("page-" + name);
  page.style.display = "flex";
  page.classList.add("active");
}

function setProgress(step) {
  const steps = ["prog-1","prog-2","prog-3"];
  steps.forEach((id, i) => {
    const el = document.getElementById(id);
    el.classList.remove("active","done");
    if (i + 1 < step) el.classList.add("done");
    else if (i + 1 === step) el.classList.add("active");
  });
}

// ── ÉTAPE 1 : SQLi ───────────────────────────────────────
async function doLogin() {
  const username = document.getElementById("login-user").value;
  const password = document.getElementById("login-pass").value;
  hide("login-error"); hide("login-success");

  try {
    const res  = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();

    if (data.success) {
      setText("login-success", "✅ Authentication bypassed!\n🚩 " + data.flag);
      show("login-success");
      setTimeout(() => {
        document.getElementById("logged-user").textContent = data.user;
        document.getElementById("flag1").textContent = "🚩 " + data.flag;
        setProgress(2);
        showPage("dashboard");
      }, 1500);
    } else {
      setText("login-error", "❌ " + data.message);
      show("login-error");
    }
  } catch(e) {
    setText("login-error", "❌ Cannot reach server.");
    show("login-error");
  }
}

// ── ÉTAPE 2 : File Upload ────────────────────────────────
async function doUpload() {
  const fileInput = document.getElementById("file-input");
  const file = fileInput.files[0];
  hide("upload-error"); hide("upload-success");
  if (!file) return;

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res  = await fetch("/api/upload", { method: "POST", body: formData });
    const data = await res.json();

    if (data.success) {
      setText("upload-success", `✅ File uploaded successfully!\n📁 Path: ${data.path}\n🚩 ${data.flag}`);
      show("upload-success");
      setTimeout(() => {
        document.getElementById("flag2").textContent = "🚩 " + data.flag;
        document.getElementById("rce-file").value = file.name;
        setProgress(3);
        showPage("rce");
      }, 2000);
    } else {
      setText("upload-error", "❌ " + data.message);
      show("upload-error");
    }
  } catch(e) {
    setText("upload-error", "❌ Cannot reach server.");
    show("upload-error");
  }
}

// ── ÉTAPE 3 : RCE ────────────────────────────────────────
async function doRCE() {
  const file = document.getElementById("rce-file").value;
  hide("rce-error");
  hide("rce-output");
  hide("flag3");

  try {
    const res  = await fetch("/api/exec?file=" + encodeURIComponent(file));
    const data = await res.json();

    if (data.success) {
      const out = document.getElementById("rce-output");
      out.textContent = `$ node /uploads/${file}\n> ${data.output}`;
      show("rce-output");

      setTimeout(() => {
        const flag = document.getElementById("flag3");
        flag.textContent = `🏴 SYSTEM COMPROMISED\n\n${data.flag}\n\nMegaCorp has been fully pwned.`;
        show("flag3");
      }, 800);
    } else {
      setText("rce-error", "❌ " + data.message);
      show("rce-error");
    }
  } catch(e) {
    setText("rce-error", "❌ Cannot reach server.");
    show("rce-error");
  }
}
